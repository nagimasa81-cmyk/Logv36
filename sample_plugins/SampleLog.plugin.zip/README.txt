Sample plugin. Install from LogMergeTool > Update File Type.
